using UnityEngine;
using System.Collections;

public class Surface : MonoBehaviour 
{

//---------------------------------------------------------------------------FIELDS:
	
	private const float EXTRUSION_SCALER = 1.0f;
	
//-------------------------------------------------------------MONOBEHAVIOR METHDOS:
	
//--------------------------------------------------------------------------METHODS:

}