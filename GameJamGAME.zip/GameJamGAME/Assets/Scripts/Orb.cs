using UnityEngine;
using System.Collections;

public class Orb : Singleton<Orb> {
	
//---------------------------------------------------------------------------FIELDS:	
	
	public float radius;
	private float timer;

//-------------------------------------------------------------MONOBEHAVIOR METHDOS:

	void Start () 
	{
		timer = 0.0f;
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		
		timer += Time.deltaTime;
		gameObject.transform.localScale =  0.25f * new Vector3 (Mathf.Sin(timer)/2.0f + 2.0f, Mathf.Sin(timer)/2.0f + 2.0f, Mathf.Sin(timer)/2.0f + 2.0f);
		gameObject.transform.localRotation = Quaternion.Euler( new Vector3 (50.0f * timer, 50.0f * timer, 50.0f *timer));		
		
	}

//--------------------------------------------------------------------------METHODS:
	
}
