using UnityEngine;
using System.Collections;

public enum SurfaceType {

	REFLECTIVE, DEAD, TEMP, PERM, STICKY, ELASTIC
}
