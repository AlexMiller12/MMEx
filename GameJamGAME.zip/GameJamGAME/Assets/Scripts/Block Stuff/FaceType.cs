using UnityEngine;
using System.Collections;

public enum FaceType {

	XPOS, XNEG, YPOS, YNEG, ZPOS, ZNEG
}
