using UnityEngine;
using System.Collections;

public class PermExtrudeSurface : Surface {

//---------------------------------------------------------------------------FIELDS:	

//-------------------------------------------------------------MONOBEHAVIOR METHDOS:
	
//--------------------------------------------------------------------------METHODS:
	
}
