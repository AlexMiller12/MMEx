using UnityEngine;
using System.Collections;

public class DeadSurface : Surface {

//---------------------------------------------------------------------------FIELDS:	

//-------------------------------------------------------------MONOBEHAVIOR METHDOS:
	
//--------------------------------------------------------------------------METHODS:
	
}
